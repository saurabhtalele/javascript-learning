//making an empty array to push input text field
let list1 = []
//grabbing html text id 
const inputEl = document.getElementById("input-el")
//grabbing html button id 
const inputBtn = document.getElementById("input-btn")
//grabbing unlisted list id from html for making a list 
const ulEl = document.getElementById("ul-el")
//grabbing delete butoon id from html to selet all items in list arry
const deleteBtn = document.getElementById("delete-btn")

//getting elemnts from localstorage in form of array i.e where jason.parse used 
const list1FromLocalStorage = JSON.parse( localStorage.getItem("myLeads") )

// after refreshing brawser that contain will be their
// now seeitng that array which we have got from storage to our list 1
if (list1FromLocalStorage) {
    list1 = list1FromLocalStorage
    render(list1)
}

//to render listed text in list1 i.e array
function render(list1) {
    let listItems = "";
    for (let i = 0; i < list1.length; i++) {
        listItems +="<li>" + list1[i] + "</li>";
  }
    ulEl.innerHTML = listItems;
}

//to delete all things from list1
deleteBtn.addEventListener("dblclick", function() {
    localStorage.clear()
    //now setting again list as empty array
    list1 = []
    //aftre clearing  use reder whole document
    render(list1)
})

//take input from save input button
inputBtn.addEventListener("click", function() {
    //pushing elements in list1 ie. our empty list to get populated by input text
    list1.push(inputEl.value)
    //setiing our input text feild as clean (after button press save it will clear that feild )
    inputEl.value = ""
    // savin data in key and value in local storage (local storage only understands string so use jason stingfy to that array)
    localStorage.setItem("list1", JSON.stringify(list1) )
    //render function to display
    render(list1)
})