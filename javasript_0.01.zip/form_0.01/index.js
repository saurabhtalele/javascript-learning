let form = document.getElementById("form");

let password = document.getElementById("password");

let confirm_password = document.getElementById("confirm password");

let message = document.getElementById("message");

var ele = document.getElementsByName('fav_language');

/*by default we dont have valid form {means while its not filled}*/
let isvalid = false;
let passwordmatch = false;
let iscliked=false


function validedform() {
    /* check valided form method constrain api it will return boolean value*/
    /*only all green then only submited*/
    if (!isvalid) {
        isvalid = form.checkValidity();
        message.textContent = 'please fill out full form';
        message.style.color = 'red';
        /* if form not feild it will not check further and return hear only */

    }

    if (password.value == confirm_password.value) {
        passwordmatch = true;
        password.style.borderColor = 'green'
        confirm_password.style.borderColor = 'green'

    }
    else {
        passwordmatch = false;
        password.style.borderColor = 'red'
        confirm_password.style.borderColor = 'red'
        message.innerHTML = 'please use same passward in confirm passward';
        message.style.color = 'red';
        /* return to breke the function */
        return;
    }

    if (!iscliked){
        for (var i=0;i<ele.length;i++)
        if(ele[i].checked){
            iscliked=true;
            break

        }
        message.innerHTML = 'please select favoirate lang ';
       }
       
    if (isvalid && passwordmatch && iscliked) {
        message.innerHTML = 'succefully submitted';
        message.style.color = 'green'

    }
}

function storedata() {
    const userdata = {
        name: form.name.value,
        phone: form.phone.value,
        email: form.email.value,
        password: form.password1.value,
        fav_lang: document.querySelector('input[name="fav_language"]:checked').value,  
        };
    console.log(userdata);
}


function ToProcessdata(e) {
    /*when submit button called which is inside form it will submit all data in url we dont want because there is no backed to accept form*/
    e.preventDefault();
    validedform();
    if (isvalid && passwordmatch && iscliked) {

        storedata();
    }
}

form.addEventListener('submit', ToProcessdata);

