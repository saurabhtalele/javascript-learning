/* j is button obj will listen click event */
var add = document.getElementById("j");
console.log("hi");
add.addEventListener("click", function () {
    var num1 = Number(document.getElementById("1num").value);
    var num2 = Number(document.getElementById("2num").value);

    var total = document.getElementById("total");

    var c = num1 + num2
    total.innerHTML = c
});



